export class UserCreatedEvent {
  id: number;
  email: string;
  name: string;
}
