export const selectUser = {
  id: true,
  name: true,
  email: true,
};
