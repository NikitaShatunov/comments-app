import { selectUser } from './select-user';

export const selectPortfolio = {
  id: true,
  title: true,
  description: true,
  createdAt: true,
  user: selectUser,
};
