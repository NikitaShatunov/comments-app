export class CommentDeletedEvent {
  id: number;
}
